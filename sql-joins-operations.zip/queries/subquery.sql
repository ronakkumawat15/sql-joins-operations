SELECT e.emp_no,e.first_name,
(SELECT salary FROM salaries s
WHERE s.emp_no = e.emp_no
AND s.to_date > CURDATE()) AS current_salary
FROM employees e
WHERE e.emp_no BETWEEN 10001 AND 10010;
