# Explanation

## INNER JOIN
Returns matching records from both tables.

## LEFT JOIN
Returns all records from left table + matches from right.

## UNION
Combines multiple query results.

## Subquery
Query inside another query.

## DISTINCT
Removes duplicate values.

## Optimization
Indexes improve performance drastically.

## Common Errors
- Missing JOIN condition → Cartesian product
- NULL handling issues
