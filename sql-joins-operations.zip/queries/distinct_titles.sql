SELECT DISTINCT title
FROM titles
WHERE to_date > CURDATE();
