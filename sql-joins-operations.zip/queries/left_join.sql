SELECT e.emp_no,
CONCAT(e.first_name,' ',e.last_name) AS employee,
CONCAT(m.first_name,' ',m.last_name) AS manager
FROM employees e
LEFT JOIN dept_manager dm ON dm.dept_no = (
SELECT dept_no FROM dept_emp
WHERE emp_no = e.emp_no AND to_date > CURDATE())
LEFT JOIN employees m ON dm.emp_no = m.emp_no
WHERE dm.to_date > CURDATE()
LIMIT 5;
