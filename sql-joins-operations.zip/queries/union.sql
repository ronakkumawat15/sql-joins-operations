SELECT emp_no,'Active' AS status,dept_name
FROM dept_emp de
JOIN departments d ON de.dept_no = d.dept_no
WHERE de.to_date > CURDATE()
AND d.dept_name='Sales'
UNION ALL
SELECT emp_no,'Former',dept_name
FROM dept_emp de
JOIN departments d ON de.dept_no = d.dept_no
WHERE de.to_date <= CURDATE()
AND d.dept_name='Sales';
