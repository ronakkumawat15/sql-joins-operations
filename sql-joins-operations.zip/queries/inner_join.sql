SELECT e.emp_no,
CONCAT(e.first_name,' ',e.last_name) AS name,
d.dept_name
FROM employees e
INNER JOIN dept_emp de ON e.emp_no = de.emp_no
INNER JOIN departments d ON de.dept_no = d.dept_no
WHERE de.to_date > CURDATE()
LIMIT 5;
