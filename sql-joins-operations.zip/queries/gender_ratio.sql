SELECT d.dept_name,
ROUND(100*SUM(IF(e.gender='F',1,0))/COUNT(*)) AS female_pct,
ROUND(100*SUM(IF(e.gender='M',1,0))/COUNT(*)) AS male_pct
FROM departments d
JOIN dept_emp de ON d.dept_no = de.dept_no
JOIN employees e ON de.emp_no = e.emp_no
WHERE de.to_date > CURDATE()
GROUP BY d.dept_name
HAVING COUNT(*) > 10000;
