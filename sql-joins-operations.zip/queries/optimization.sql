CREATE INDEX idx_emp ON salaries (emp_no, salary, to_date);

EXPLAIN ANALYZE
SELECT e.emp_no, MAX(s.salary)
FROM employees e
JOIN salaries s ON e.emp_no = s.emp_no
GROUP BY e.emp_no
LIMIT 10;
