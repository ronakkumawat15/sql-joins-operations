# 📊 SQL Project: Multi-Table Operations & Joins

## 📖 Description
This project demonstrates advanced SQL concepts focused on multi-table operations, joins, subqueries, and performance optimization using a real-world employees dataset.

---

## 🎯 Objective
To build complex SQL queries combining multiple tables and generate meaningful relational insights.

---

## 🛠️ Tools Used
- MySQL
- SQL

---

## 📊 Dataset
- employees (300k+ records)
- departments
- dept_emp
- salaries (2.8M+ records)
- titles

---

## 🔍 Key Concepts Covered
- INNER JOIN, LEFT JOIN
- UNION / UNION ALL
- Correlated Subqueries
- DISTINCT & duplicate handling
- Conditional aggregation
- Query optimization (INDEX, EXPLAIN)

---

## 📂 Project Structure
sql-joins-operations/
│
├── README.md
├── queries/
├── documentation/
└── outputs/

---

## 📈 Skills Gained
- Multi-table data integration
- Writing complex joins
- Handling NULL values
- Query performance optimization

---

## 💡 Key Learnings
- INNER JOIN vs LEFT JOIN differences
- Avoiding Cartesian products
- Using indexes for faster queries
- Filtering early improves performance

---

## 🚀 Conclusion
This project builds strong SQL skills for real-world data engineering and analytics tasks.
